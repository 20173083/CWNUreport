#include <stdio.h>
#include <stdlib.h>
 
typedef struct Listnode{
 int data;
 struct Listnode *link;
}Listnode;
  
Listnode *create(); 
void add(Listnode *, int);  
void print(Listnode*);  
void del(Listnode *,int);
int search(Listnode *, int);  

 
int main(int argc, char *argv[]) {
 Listnode *h;
 int i;
 int num=0;
 int n=0;
 h=create();
  
 printf("Enter 5 elements in array: ");
 for(i=0;i<5;i++){
   scanf("%d",&num); 
   add(h,num);
 }
 printf("Stored element in array: "); 
 print(h);
 
 printf("Enter poss. of element to delete: ");
 scanf("%d",&n); 
 
 del(h,search(h,n));
 printf("After deletion elements in array: ");
 print(h);   
   
 return 0;
}
 
Listnode *create(){
  Listnode *p;
   
  p=(Listnode*)malloc(sizeof(Listnode));
  p->data=0;
  p->link=NULL;
   
  return p;
}
void print(Listnode* h){
  Listnode *p;
  p=h;
   
  while(p->link!=NULL){
   p=p->link;
   printf("%3d",p->data);
  }
  printf("\n");
}

int search(Listnode *h, int m){
  Listnode *p;
  p=h;
  int cnt=0;
   
  while(p->link!=NULL){
    p=p->link;
    cnt++;
 if(cnt==m)  return p->data;
  }
   
   
   return;
}

void del(Listnode *h,int search){
  Listnode *p;
  Listnode *q;
  q=create();
  p=h;
   
  while(p->link!=NULL){
     q=p;
  p=p->link;
  if(p->data==search){
   q->link=p->link;
   free(p); break;
 }  
   }
} 
void add(Listnode *h, int data){
 Listnode *p, *q;
 q=create();
 q->data=data;
  
 p=h;
  
 while(p->link!=NULL){
   p=p->link;
   }
    
 p->link=q;
   
}

