#include <Stdio.h>
int main(void){
	int array[5];  
	int i=0; 
	int n=0;  
	  
	printf("Enter elements in array: ");
	for(i=0;i<5;i++)
		scanf("%d",&array[i]);	
	 
	printf("Stored element in array: ");
	for(i=0;i<5;i++)
		printf("%d ",array[i]);
	 
	
	printf("\nEnter poss. of element to delte: ")
	;
	scanf("%d", &n);
	 
	for(i=n-1;i<=4;i++)
		array[i]=array[i+1];	
	 
	printf("After deletion elements in array: ");
	for(i=0;i<4;i++)
		printf("%d ",array[i]);
	return 0;	
}
