#include <stdio.h>
#define MAX 50
int stack[MAX];
int top=-1;

void pop(){
	top--;
	stack[top];
}
void push(int num){
	top++;
	stack[top]=num;
}
int main(void){
	int n=0;
	int num=0;
	int i=0;
	char c1;
	while(1){
		printf("1. push \n");
		printf("2. pop \n");
		printf("3. display \n");
		printf("4. exit \n");
		printf("enter your choice : ");
		scanf("%d",&n);
		
		switch(n)
		{
			case 1:
				printf("Enter element in stack : ");
				scanf("%d",&num);
				push(num);
				
				break;
			case 2:
				printf("deleted data is : ");
				scanf("%d",&num);
				pop();
				
				break;	
			case 3:
				for(i=top;i>=0;i--)
					printf("%d\n",stack[i]);
						
				break;
			case 4:
				break; 
		}
		if(n==4)
			break;	
	}
	return 0;
}
