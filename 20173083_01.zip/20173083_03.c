#include <stdio.h>
#include <stdlib.h>

typedef struct Listnode{
 int data;
 struct Listnode *link;
}Listnode;
  
Listnode *create(); 
void add(Listnode *, int);  
void print(Listnode*);  
int search(Listnode *, int);  
void add2(Listnode *,int,int);  
 
int main(int argc, char *argv[]) {
 Listnode *h;
 int i;
 int num=0;
 int n=0;
 h=create();
 
 printf("Enter 5 elements in array: ");
 for(i=0;i<5;i++){
   scanf("%d",&num); 
   add(h,num);
 }
 
 printf("Stored element in array: "); 
 print(h);
 
 printf("Enter position for enter element: ");
 scanf("%d",&n);
 printf("Enter new element: ");
 scanf("%d",&num); 
 add2(h,search(h,n),num);
 printf("Stored data in array: ");
 print(h); 
 
 return 0;
}
 
Listnode *create(){
  Listnode *p;
   
  p=(Listnode*)malloc(sizeof(Listnode));
  p->data=0;
  p->link=NULL;
   
  return p;
}
 
void add(Listnode *h, int data){
 Listnode *p, *q;
 q=create();
 q->data=data;
  
 p=h;
  
 while(p->link!=NULL){
   p=p->link;
   }
    
 p->link=q;
   
}

void print(Listnode* h){
  Listnode *p;
  p=h;
   
  while(p->link!=NULL){
   p=p->link;
   printf("%3d",p->data);
  }
  printf("\n");
}

int search(Listnode *h, int m){
  Listnode *p;
  p=h;
  int cnt=0;
   
  while(p->link!=NULL){
    p=p->link;
    cnt++;
 if(cnt==m)  return p->data;
  }
   
   
   return;
}
void add2(Listnode *h,int search,int add){
  Listnode *p,*q;
  p=h;
  q=create();
  q->data=add;
    
   
  while(p->link!=NULL){
    
   if(p->link->data==search){
       q->link=p->link;
       p->link=q; break;  }
    
   p=p->link;    
} 
   
}
 

