#include <stdio.h>

int main(void){
	int n,num=0;
	int front=-1;
	int rear=-1;
	int queue[3];
	int i=0;
	
	while(1){
		printf("1. Insertion \n");
		printf("2. Deletion \n");
		printf("3. Display \n");
		printf("0. Exit \n");
		printf("Select Option : ");
		scanf("%d",&n);
		
		switch(n)
		{
			case 1:
				printf("Element : ");
				scanf("%d",&num);
				if(rear==2){
					printf("Queue is Full\n");
				}
				else{		
					printf("Successfully Insert\n");
					rear=(rear+1);
					queue[rear]=num;
				}
				break;
			case 2:
				printf("Deleted item : ");
				scanf("%d",&num);
				front = front+1;
				
				break;	
			case 3:
				printf("Items : ");
				for(i=front+1;i<=rear;i++)
					printf("%d ",queue[i]);
				printf("\n");	
				break;
			case 0:
				break; 
		}
		if(n==0)
			break;	
	}
	return 0;
}
