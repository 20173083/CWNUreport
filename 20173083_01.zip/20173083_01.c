#include <Stdio.h>
int main(void){
	int array[6]; 
	int i=0; 
	int n=0;  
	int t=0;  
	printf("Enter 5 elements in array: ");
	for(i=0;i<5;i++)
		scanf("%d",&array[i]);	
	 
	
	printf("Stored element in array: ");
	for(i=0;i<5;i++)
		printf("%d ",array[i]);
	 
	
	printf("\nEnter position for enter element: ");
	scanf("%d", &n);
	printf("Enter new element: ");
	scanf("%d", &t);
	 
	for(i=5;i>=n;i--)
		array[i]=array[i-1];	
	array[n-1]=t;
	 
	printf("Stored data in array: ");
	for(i=0;i<=5;i++)
		printf("%d ",array[i]);
	return 0;	
}
